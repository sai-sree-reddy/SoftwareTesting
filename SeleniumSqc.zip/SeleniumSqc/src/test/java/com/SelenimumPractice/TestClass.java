package com.SelenimumPractice;

import org.testng.annotations.Test;

public class TestClass {
	@Test
	public void foo() {
	System.out.println("Testing");	
		
	}

}
