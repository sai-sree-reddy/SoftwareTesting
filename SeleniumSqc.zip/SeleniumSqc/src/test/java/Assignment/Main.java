package Assignment;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Main {

	 public static void takeScreenshot(WebDriver driver, String fileName, String scenario) throws IOException {
	        // Convert WebDriver object to TakesScreenshot
	        TakesScreenshot screenshot = (TakesScreenshot) driver;

	     // Capture the screenshot as a file
	        File sourceFile = screenshot.getScreenshotAs(OutputType.FILE);

	        // Specify the destination file
	        File destinationFile = new File("/Users/saisreepothireddygari/Documents/ScreenShots" +"/" +scenario + "/" + fileName + "_" + System.currentTimeMillis() + ".png");

	        // Copy the screenshot file to the specified destination
	        Files.copy(sourceFile.toPath(), destinationFile.toPath());
	    }
}
