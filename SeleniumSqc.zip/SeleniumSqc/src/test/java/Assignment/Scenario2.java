package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.InputStream;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;



import java.time.Duration;

public class Scenario2 {
    WebDriver driver;
    WebDriverWait wait;

    @Parameters("browserName")
    @BeforeTest
    public void InitialiseBrowser(String browserName) {
        switch (browserName.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions options=new ChromeOptions();
                options.addArguments("--disable-extensions");
                HashMap<String, Object> chromePrefs = new HashMap<>();
                chromePrefs.put("plugins.always_open_pdf_externally", true);
                options.setExperimentalOption("prefs", chromePrefs);
                driver = new ChromeDriver(options);
    
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            default:
                System.out.println("Browser name is invalid");
                break;
        }
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Parameters("sleepTime")
    @AfterTest
    public void TearDown(Long sleepTime) throws InterruptedException {
        Thread.sleep(sleepTime);
        driver.quit();
    }
    
    
  @Parameters("url")
@Test(priority = 1)
public void LaunchApp(String url) {
    driver.get("https://canvas.northeastern.edu/");
}

@Parameters({"username", "password","loginname" })
@Test(priority = 2)
 public void EnterLoginDetails(String userName, String password, String loginname) throws InterruptedException, IOException {
	  
 
	 File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
     FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario2/screenshot1.png"));
	        
	    	driver.findElement(By.cssSelector(".wp-block-button__link.wp-element-button")).click();
	    	WebElement usernameInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
	        usernameInput.sendKeys(userName);
	        driver.findElement(By.id("idSIButton9")).click();

	        // Wait for the password field to be clickable and enter the password.
	        WebElement passwordInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
	        passwordInput.sendKeys(password);
	        driver.findElement(By.id("idSIButton9")).click();
	        WebElement otherOptionsLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.button--link[href*='/frame/v4/auth/all_methods?sid=frameless-']")));
	        otherOptionsLink.click();

	        WebElement spanElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='method-description-displayed' and contains(text(), 'Send to \"iOS\"')]")));
	        spanElement.click();

	        WebElement trustBrowserButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
	        trustBrowserButton.click();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25)); // Use Duration.ofSeconds for the timeout
	        WebElement No = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
	        No.click();
	        WebElement calendarLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("global_nav_calendar_link")));

	        
	     // Click the link
	     calendarLink.click();
	     
	     FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario2/screenshot2.png"));
	     WebElement createNewEventLink = new WebDriverWait(driver, Duration.ofSeconds(10))
	    	        .until(ExpectedConditions.elementToBeClickable(By.id("create_new_event_link")));
	     String excelFilePath = "/Users/saisreepothireddygari/Documents/SelenimumPractice/data.xlsx";
			FileInputStream inputStream = new FileInputStream(excelFilePath);
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet sheet = workbook.getSheet("Sheet1");

	     WebElement calendar = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='global_nav_calendar_link']")));
			calendar.click();
			Thread.sleep(500);
	
			FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario2/screenshot3.png"));
			for (int i = 1; i <= 2; i++) {
				Row r = sheet.getRow(i);
				String title = r.getCell(3).getStringCellValue();
				String date = r.getCell(4).getStringCellValue();
				String time = r.getCell(5).getNumericCellValue() + "";
				String Details = r.getCell(7).getStringCellValue();
			// Add action
				WebElement add = wait
						.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='create_new_event_link']")));
         		add.click();

 				// To-do action
				WebElement event1 = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"edit_event_tabs\"]/ul/li[2]")));
				event1.click();

				Thread.sleep(2000);
				WebElement titleW = driver.findElement(By.id("planner_note_title"));
				WebElement dateW = driver.findElement(By.id("planner_note_date"));
				WebElement timeW = driver.findElement(By.id("planner_note_time"));
			WebElement detailW = driver.findElement(By.id("details_textarea"));
				titleW.sendKeys(title);
				dateW.clear();
				dateW.sendKeys(date);
				timeW.sendKeys(time);
				detailW.sendKeys(Details);

				Thread.sleep(500);
    //takeScreenshot(driver, "createElementbeforeClick" + i, "s2");
				WebElement submit = driver
						.findElement(By.xpath("//*[@id=\"edit_planner_note_form_holder\"]/form/div[2]/button"));
				submit.click();
	 
				FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario2/screenshot4.png"));
	    	
	    }
	    
}
}
	    
//  
//  @Parameters("url")
//  @Test(priority = 1)
//  public void LaunchApp(String url) {
//      driver.get("https://service.northeastern.edu/tech?id=classrooms");
//  }
//  
//
//  @Test(priority = 2)
//  public void clickonhealthsciencecenter() {
//	    
//  	try {
//  	WebElement element = driver.findElement(By.xpath("//a[contains(@ng-href, 'classroom_details') and contains(@href, 'classroom=9ac92fb397291d905a68bd8c1253afd0')]"));
//  	element.click();
//  	WebDriverWait link = new WebDriverWait(driver, Duration.ofSeconds(50));
//  	
//  	String pdfLink = "https://nuflex.northeastern.edu/wp-content/uploads/2020/11/Hybrid_Nuflex_Classroom.pdf";
//      ((JavascriptExecutor) driver).executeScript("window.open('" + pdfLink + "','_blank');");
//      
//      
////   // Add a delay to ensure that the PDF file has loaded
////      try {
////          Thread.sleep(20000); // Wait for 5 seconds
////      } catch (InterruptedException e) {
////          e.printStackTrace();
////      }
////      
////      WebElement targetElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.id("maskedImage")));
////
////		// Create an instance of the Actions class
////		Actions actions = new Actions(driver);
////
////		// Right-click on the target element
////		actions.contextClick(targetElement).perform();
////      
////      Robot robot = new Robot();
////		robot.keyPress(KeyEvent.VK_P);
////		robot.keyRelease(KeyEvent.VK_P);
////
////		// Wait for the Print dialog to open (adjust the wait time as needed)
////		Thread.sleep(2000);
////
////		// Press the 'Enter' key to open the Save as PDF dialog
////		robot.keyPress(KeyEvent.VK_ENTER);
////		robot.keyRelease(KeyEvent.VK_ENTER);
////
////		// Wait for the Save as PDF dialog to open (adjust the wait time as needed)
////		Thread.sleep(2000);
////
////		// Type the desired file name and location
////		String fileName = "output.pdf";
////
////		// Type the file name directly
////		for (char c : fileName.toCharArray()) {
////		    robot.keyPress(KeyEvent.getExtendedKeyCodeForChar(c));
////		    robot.keyRelease(KeyEvent.getExtendedKeyCodeForChar(c));
////		    // Add a small delay between key presses for reliability
////		    Thread.sleep(50);
////		}
////
////		// Press the 'Enter' key to save the PDF
////		robot.keyPress(KeyEvent.VK_ENTER);
////		robot.keyRelease(KeyEvent.VK_ENTER);
////		
////      
//////      WebElement iconElement = driver.findElement(By.id("icon"));
////
////      // Perform any interactions with the icon element here, for example, clicking on it
////     // iconElement.click();
//  	} catch (Exception e) {
//         e.printStackTrace();
//     }
//  }
// }
//     
////   // driver.findElement(By.id("icon")).click();
////      Robot robot = new Robot();
////
////		// Use Robot to simulate mouse and keyboard actions
////		robot.mousePress(InputEvent.BUTTON1_MASK); // Press the left mouse button
////		robot.mouseRelease(InputEvent.BUTTON1_MASK);
////		robot.keyPress(KeyEvent.VK_META);
////		robot.delay(200);
////		robot.keyPress(KeyEvent.VK_S);
////		robot.keyRelease(KeyEvent.VK_META);
////
////		//Thread.sleep(5000);
////
////		robot.keyPress(KeyEvent.VK_ENTER);
////		robot.keyRelease(KeyEvent.VK_ENTER);
////		//Thread.sleep(2000);
////		// Quit the WebDriver
////		driver.quit();
////  	} catch (Exception e) {
////			// TODO Auto-generated catch block
////			// Handle exceptions and print the stack trace
////			e.printStackTrace();
////		}
//
//  
//  
//
// 
//    
//
//    
////    
////    @Parameters("url")
////    @Test(priority = 1)
////    public void LaunchApp(String url) {
////        driver.get("https://student.me.northeastern.edu/");
////    }
//    
////    @Parameters({"username", "password","loginname" })
////    @Test(priority = 2)
////     public void EnterLoginDetails(String userName, String password, String loginname) throws InterruptedException {
////    	
////     
////      
////      
////      WebElement usernameInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
////    usernameInput.sendKeys(userName);
////    driver.findElement(By.id("idSIButton9")).click();
////////
////////    // Wait for the password field to be clickable and enter the password.
////    WebElement passwordInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
////    passwordInput.sendKeys(password);
////    driver.findElement(By.id("idSIButton9")).click();
////    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50)); // Use Duration.ofSeconds for the timeout
////    WebElement No = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
////    No.click();
////    WebDriverWait link = new WebDriverWait(driver, Duration.ofSeconds(25));
////    WebElement resourcesLink = link.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-testid='link-resources']")));
////    resourcesLink.click();
////    wait = new WebDriverWait(driver, Duration.ofSeconds(5));
////    
//////    // Build the CSS Selector based on the src attribute
////    String cssSelector = "img[src*='academicsclassesregistrationblue.4c5fd2f5.svg']";
////    
////      try {
////        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(cssSelector)));
////      image.click();
////      } catch (Exception e) {
////     
////      WebElement image = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector)));
////      ((JavascriptExecutor) driver).executeScript("arguments[0].click();", image);
////      }
////      
////      WebDriverWait  academiccalender = new WebDriverWait(driver, Duration.ofSeconds(25)); // Use Duration.ofSeconds for the timeout
////    WebElement transcript = academiccalender.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-gtm-sh-resources-link='Academic Calendar']")));
////    transcript.click();
////      
//// // Get the current window handle
////    String currentWindowHandle = driver.getWindowHandle();
////
////    // Click on the link to open the new window
////    //WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Academic Calendar')]"));
////    //element.click();
////
////    // Switch to the new window
////    for (String windowHandle : driver.getWindowHandles()) {
////        if (!windowHandle.equals(currentWindowHandle)) {
////            driver.switchTo().window(windowHandle);
////            break;
////        }
////    }
////
////    
////    WebElement element1 = driver.findElement(By.xpath("//a[contains(@class, '__item') and contains(text(), 'Academic Calendar')]"));
////    element1.click();
////
////	
////	WebElement iframe = driver.findElement(By.id("trumba.spud.6.iframe"));
////
////	new Actions(driver).scrollToElement(iframe).perform();
////	Thread.sleep(2000);
////	// Uncheck a checkbox in the iframe
////	
////
////
////	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("trumba.spud.6.iframe")));
////	WebElement checkBox = driver.findElement(By.xpath("//*[@id=\"mixItem0\"]"));
////	if (checkBox.isSelected()) {
////		// If it's selected, uncheck it
////		checkBox.click();
////	}
////	
////	driver.switchTo().defaultContent();
////	WebElement iframe2 = driver.findElement(By.id("trumba.spud.2.iframe"));
////	WebElement bottom = driver.findElement(By.xpath("//*[@id=\"nu-global-footer\"]/footer/div[1]/div[2]/a[3]"));
////
////	new Actions(driver).scrollToElement(bottom).perform();
////	driver.switchTo().frame(iframe2);
////	Thread.sleep(500);
////	//takeScreenshot(driver, "After_go_to_bottom", "s5");
////	Thread.sleep(2000);
////	// Verify an element is displayed at the bottom
////	//WebElement table = driver.findElement(By.xpath("//*[@id=\"ctl04_ctl90_ctl00_actionsWrap\"]/table"));
////	//WebElement addToMy = table.findElement(By.id("ctl04_ctl01_ctl156_eapanelFooter_ctl00_buttonAtmc"));
////
////	//boolean checkpoint = addToMy.isDisplayed();
////	//Assert.assertTrue(checkpoint);
////	
////	JavascriptExecutor js = (JavascriptExecutor) driver;
////    js.executeScript("window.scrollBy(0,1500)");
////    }
////}
////    	
//    
//    //Scenario 2
////   
////    @Parameters("url")
////    @Test(priority = 1)
////    public void LaunchApp(String url) {
////        driver.get("https://service.northeastern.edu/tech?id=classrooms");
////    }
////    
////  
////    @Test(priority = 2)
////    public void clickonhealthsciencecenter() {
////    	try {
////    	WebElement element = driver.findElement(By.xpath("//a[contains(@ng-href, 'classroom_details') and contains(@href, 'classroom=9ac92fb397291d905a68bd8c1253afd0')]"));
////    	element.click();
////    	WebDriverWait link = new WebDriverWait(driver, Duration.ofSeconds(50));
////    	
////    	String pdfLink = "https://nuflex.northeastern.edu/wp-content/uploads/2020/11/Hybrid_Nuflex_Classroom.pdf";
////        ((JavascriptExecutor) driver).executeScript("window.open('" + pdfLink + "','_blank');");
////        
////     // Add a delay to ensure that the PDF file has loaded
////        try {
////            Thread.sleep(5000); // Wait for 5 seconds
////        } catch (InterruptedException e) {
////            e.printStackTrace();
////        }
////       
////     // driver.findElement(By.id("icon")).click();
////        Robot robot = new Robot();
////
////		// Use Robot to simulate mouse and keyboard actions
////		robot.mousePress(InputEvent.BUTTON1_MASK); // Press the left mouse button
////		robot.mouseRelease(InputEvent.BUTTON1_MASK);
////		robot.keyPress(KeyEvent.VK_META);
////		robot.delay(200);
////		robot.keyPress(KeyEvent.VK_S);
////		robot.keyRelease(KeyEvent.VK_META);
////
////		//Thread.sleep(5000);
////
////		robot.keyPress(KeyEvent.VK_ENTER);
////		robot.keyRelease(KeyEvent.VK_ENTER);
////		//Thread.sleep(2000);
////		// Quit the WebDriver
////		driver.quit();
////    	} catch (Exception e) {
////			// TODO Auto-generated catch block
////			// Handle exceptions and print the stack trace
////			e.printStackTrace();
////		}
////    }
//    
////    
////
//
//        
//
//    
// 