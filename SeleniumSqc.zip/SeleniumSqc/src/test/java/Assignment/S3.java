package Assignment;

import java.io.File;
import java.time.Duration;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class S3 {
	
	 WebDriver driver;
	    WebDriverWait wait;

	    @Parameters("browserName")
	    @BeforeTest
	    public void InitialiseBrowser(String browserName) {
	        switch (browserName.toLowerCase()) {
	            case "chrome":
	                WebDriverManager.chromedriver().setup();
	                ChromeOptions options=new ChromeOptions();
	                options.addArguments("--disable-extensions");
	                HashMap<String, Object> chromePrefs = new HashMap<>();
	                chromePrefs.put("plugins.always_open_pdf_externally", true);
	                options.setExperimentalOption("prefs", chromePrefs);
	                driver = new ChromeDriver(options);
	    
	                break;
	            case "edge":
	                WebDriverManager.edgedriver().setup();
	                driver = new EdgeDriver();
	                break;
	            case "firefox":
	                WebDriverManager.firefoxdriver().setup();
	                driver = new FirefoxDriver();
	                break;
	            default:
	                System.out.println("Browser name is invalid");
	                break;
	        }
	        driver.manage().window().maximize();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    @Parameters("sleepTime")
	    @AfterTest
	    public void TearDown(Long sleepTime) throws InterruptedException {
	        Thread.sleep(sleepTime);
	        driver.quit();
	    }
	    
	    @Parameters("url")
	    @Test(priority = 1)
	    public void LaunchApp(String url) {
	        driver.get("https://service.northeastern.edu/tech?id=classrooms");
	    }
	    

	    @Test(priority = 2)
	    public void clickonhealthsciencecenter() {
	  	    
	    	try {
	    	WebElement element = driver.findElement(By.xpath("//a[contains(@ng-href, 'classroom_details') and contains(@href, 'classroom=9ac92fb397291d905a68bd8c1253afd0')]"));
	    	element.click();
	    	WebDriverWait link = new WebDriverWait(driver, Duration.ofSeconds(50));
	    	
	    	
	    	 File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	         FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario3/screenshot1.png"));
	    	
	    	String pdfLink = "https://nuflex.northeastern.edu/wp-content/uploads/2020/11/Hybrid_Nuflex_Classroom.pdf";
	        ((JavascriptExecutor) driver).executeScript("window.open('" + pdfLink + "','_blank');");
	        
	    	} catch (Exception e) {
	            e.printStackTrace();
	        }
	     }
	    

}
