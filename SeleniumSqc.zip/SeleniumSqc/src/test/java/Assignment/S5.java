package Assignment;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class S5 {
	
	   WebDriver driver;
	    WebDriverWait wait;

	    @Parameters("browserName")
	    @BeforeTest
	    public void InitialiseBrowser(String browserName) {
	        switch (browserName.toLowerCase()) {
	            case "chrome":
	                WebDriverManager.chromedriver().setup();
	                driver = new ChromeDriver();
	                break;
	            case "edge":
	                WebDriverManager.edgedriver().setup();
	                driver = new EdgeDriver();
	                break;
	            case "firefox":
	                WebDriverManager.firefoxdriver().setup();
	                driver = new FirefoxDriver();
	                break;
	            default:
	                System.out.println("Browser name is invalid");
	                break;
	        }
	        driver.manage().window().maximize();
	        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    @Parameters("sleepTime")
	    @AfterTest
	    public void TearDown(Long sleepTime) throws InterruptedException {
	        Thread.sleep(sleepTime);
	        driver.quit();
	    }
	
	 @Parameters("url")
	    @Test(priority = 1)
	    public void LaunchApp(String url) {
	        driver.get("https://student.me.northeastern.edu/");
	    }
	    
	    @Parameters({"username", "password","loginname" })
	    @Test(priority = 2)
	     public void EnterLoginDetails(String userName, String password, String loginname) throws InterruptedException, IOException {
	    	
	     
	    	File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	         FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario5/screenshot1.png"));
	        
	      
	      WebElement usernameInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
	    usernameInput.sendKeys(userName);
	    driver.findElement(By.id("idSIButton9")).click();
	////
////	    // Wait for the password field to be clickable and enter the password.
	    WebElement passwordInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
	    passwordInput.sendKeys(password);
	    driver.findElement(By.id("idSIButton9")).click();

        WebElement otherOptionsLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.button--link[href*='/frame/v4/auth/all_methods?sid=frameless-']")));
        otherOptionsLink.click();

        WebElement spanElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='method-description-displayed' and contains(text(), 'Send to \"iOS\"')]")));
        spanElement.click();

        WebElement trustBrowserButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
        trustBrowserButton.click();
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50)); // Use Duration.ofSeconds for the timeout
	    WebElement No = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
	    No.click();
	    WebDriverWait link = new WebDriverWait(driver, Duration.ofSeconds(25));
	    WebElement resourcesLink = link.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-testid='link-resources']")));
	    resourcesLink.click();
	    wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	    
	    FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario5/screenshot2.png"));
	    
//	    // Build the CSS Selector based on the src attribute
	    String cssSelector = "img[src*='academicsclassesregistrationblue.4c5fd2f5.svg']";
	    
	      try {
	        WebElement image = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(cssSelector)));
	      image.click();
	      } catch (Exception e) {
	     
	      WebElement image = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector)));
	      ((JavascriptExecutor) driver).executeScript("arguments[0].click();", image);
	      }
	      
	      WebDriverWait  academiccalender = new WebDriverWait(driver, Duration.ofSeconds(25)); // Use Duration.ofSeconds for the timeout
	    WebElement transcript = academiccalender.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-gtm-sh-resources-link='Academic Calendar']")));
	    transcript.click();
	      
	 // Get the current window handle
	    String currentWindowHandle = driver.getWindowHandle();

	    // Click on the link to open the new window
	    //WebElement element = driver.findElement(By.xpath("//a[contains(text(), 'Academic Calendar')]"));
	    //element.click();

	    // Switch to the new window
	    for (String windowHandle : driver.getWindowHandles()) {
	        if (!windowHandle.equals(currentWindowHandle)) {
	            driver.switchTo().window(windowHandle);
	            break;
	        }
	    }
	    
	    
	    WebElement element1 = driver.findElement(By.xpath("//a[contains(@class, '__item') and contains(text(), 'Academic Calendar')]"));
	    element1.click();

		
		WebElement iframe = driver.findElement(By.id("trumba.spud.6.iframe"));

		new Actions(driver).scrollToElement(iframe).perform();
		Thread.sleep(2000);
		// Uncheck a checkbox in the iframe
		
		   FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario5/screenshot3.png"));

		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("trumba.spud.6.iframe")));
		WebElement checkBox = driver.findElement(By.xpath("//*[@id=\"mixItem0\"]"));
		if (checkBox.isSelected()) {
			// If it's selected, uncheck it
			checkBox.click();
		}
		
		driver.switchTo().defaultContent();
		WebElement iframe2 = driver.findElement(By.id("trumba.spud.2.iframe"));
		WebElement bottom = driver.findElement(By.xpath("//*[@id=\"nu-global-footer\"]/footer/div[1]/div[2]/a[3]"));
		
		new Actions(driver).scrollToElement(bottom).perform();
		driver.switchTo().frame(iframe2);
		Thread.sleep(500);
		//takeScreenshot(driver, "After_go_to_bottom", "s5");
		Thread.sleep(2000);
		
		
				WebElement table = driver.findElement(By.xpath("//*[@id=\"ctl04_ctl90_ctl00_actionsWrap\"]/table"));
				WebElement addToMy = table.findElement(By.id("ctl04_ctl90_ctl00_buttonAtmc"));

				boolean checkpoint = addToMy.isDisplayed();
				Assert.assertTrue(checkpoint);
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,1500)");
	    }
	}