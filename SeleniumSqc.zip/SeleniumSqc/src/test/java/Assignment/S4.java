package Assignment;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.awt.Window;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.implementation.bytecode.Throw;

import java.time.Duration;

public class S4 {
    WebDriver driver;
    WebDriverWait wait;

    @Parameters("browserName")
    @BeforeTest
    public void InitialiseBrowser(String browserName) {
        switch (browserName.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            default:
                System.out.println("Browser name is invalid");
                break;
        }
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Parameters("sleepTime")
    @AfterTest
    public void TearDown(Long sleepTime) throws InterruptedException {
        Thread.sleep(sleepTime);
        driver.quit();
    }

    @Parameters("url3")
    @Test(priority = 1)
    public void LaunchApp(String url3) {
        driver.get(url3);
    }
    
    @Test(priority = 2)
    public void Launch() throws InterruptedException{

    	 // Wait for 5 seconds before taking the screenshot
  try {
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(screenshotFile, new File("D:\\Selenium\\Scenario-4\\screenshot1.png"));
    } catch (IOException e) {
        e.printStackTrace();
    }
    	 
  Thread.sleep(5000);
    	WebElement link = driver.findElement(By.cssSelector("a[aria-label='digital repository service, opens in a new window']"));
    	link.click();
    	  
    	
    }
    @Test(priority = 3)
    
    public void  scrolldown() throws IOException {
    	 String currentWindowHandle = driver.getWindowHandle();

         for (String windowHandle : driver.getWindowHandles()) {
             if (!windowHandle.equals(currentWindowHandle)) {
                 driver.switchTo().window(windowHandle);
                 break;
             }
         }
         
         try {
             File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
             FileUtils.copyFile(screenshotFile, new File("D:\\Selenium\\Scenario-4\\screenshot2.png"));
         } catch (IOException e) {
             e.printStackTrace();
         }
         	 
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	js.executeScript("window.scrollBy(0,1000)");
    	
    	 WebElement datasetsLink = driver.findElement(By.linkText("Datasets"));
         datasetsLink.click();
         
         File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
         FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario4/screenshot1.png"));
         WebElement zipFileLink = driver.findElement(By.xpath("//a[@href='/downloads/neu:bz616j94n?datastream_id=content']"));
         zipFileLink.click();
        

    }
    }
    
    