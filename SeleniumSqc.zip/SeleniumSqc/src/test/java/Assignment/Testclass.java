package Assignment;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import java.awt.AWTException;
import java.awt.Desktop.Action;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.devtools.v120.tethering.model.Accepted;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import static Assignment.Main.takeScreenshot;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Testclass {
    private WebDriver driver;
    private WebDriverWait wait;

    @Parameters("browserName")
    @BeforeTest
    public void InitialiseBrowser(String browserName) {
        switch (browserName.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                WebDriverManager.chromedriver().setup();
                ChromeOptions options=new ChromeOptions();
                options.addArguments("--disable-extensions");
                HashMap<String, Object> chromePrefs = new HashMap<>();
                chromePrefs.put("plugins.always_open_pdf_externally", true);
                options.setExperimentalOption("prefs", chromePrefs);
                driver = new ChromeDriver(options);
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            default:
                System.out.println("Browser name is invalid");
                break;
        }
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Parameters("sleepTime")
    @AfterTest
    public void TearDown(Long sleepTime) throws InterruptedException {
        Thread.sleep(sleepTime);
        driver.quit();
    }

    @Parameters("url")
    @Test(priority = 1)
    public void LaunchApp(String url) {
        driver.get(url);
    }

//    @Test(priority = 2)
//    public void Screenshot() {
//        try {
//            Thread.sleep(5000); // Wait for 5 seconds before taking the screenshot
//
//            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//            FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario1/screenshot1.png"));
//        } catch (InterruptedException e) {
//            System.err.println("Thread was interrupted while waiting to take the screenshot.");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    @Parameters({"username", "password", "loginname", "url4"})
    @Test(priority = 3)
    public void EnterLoginDetails(String userName, String password, String loginname, String url4) throws InterruptedException, AWTException, IOException {
        
    	 File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
      FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario1/screenshot1.png"));
    	 
    	WebElement usernameInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
        usernameInput.sendKeys(userName);
        driver.findElement(By.id("idSIButton9")).click();

        WebElement passwordInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
        passwordInput.sendKeys(password);
        driver.findElement(By.id("idSIButton9")).click();

        WebElement otherOptionsLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.button--link[href*='/frame/v4/auth/all_methods?sid=frameless-']")));
        otherOptionsLink.click();

        WebElement spanElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='method-description-displayed' and contains(text(), 'Send to \"iOS\"')]")));
        spanElement.click();

        WebElement trustBrowserButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
        trustBrowserButton.click();

        WebElement noButton = new WebDriverWait(driver, Duration.ofSeconds(25))
                .until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
        noButton.click();

        WebElement resourcesLink = new WebDriverWait(driver, Duration.ofSeconds(25))
                .until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-testid='link-resources']")));
        resourcesLink.click();

        String cssSelector = "img[src*='academicsclassesregistrationblue.4c5fd2f5.svg']";
        WebElement image;
        try {
            image = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(cssSelector)));
            image.click();
        } catch (Exception e) {
            image = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssSelector)));
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", image);
        }
        
      
     FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario1/screenshot2.png"));

        WebElement transcript = new WebDriverWait(driver, Duration.ofSeconds(25))
                .until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-gtm-sh-resources-link='My Transcript']")));
        transcript.click();
        
    

        String currentWindowHandle = driver.getWindowHandle();

        for (String windowHandle : driver.getWindowHandles()) {
            if (!windowHandle.equals(currentWindowHandle)) {
                driver.switchTo().window(windowHandle);
                break;
            }
        }

    	
        
        WebElement usernameInput1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
        usernameInput1.sendKeys("pothireddygari.s");

        WebElement passwordInput1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
        passwordInput1.sendKeys(password);
        WebElement button = driver.findElement(By.name("_eventId_proceed"));
        button.click();
        Thread.sleep(10000);
        Select drpCountry = new Select(wait.until(ExpectedConditions.elementToBeClickable(By.id("levl_id"))));
		drpCountry.selectByVisibleText("Graduate");
		
		
		

		WebElement findTranscript = wait
				.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[3]/form/input")));
		findTranscript.click();
		Thread.sleep(500);
		  FileUtils.copyFile(screenshotFile, new File("/Users/saisreepothireddygari/Documents/ScreenShots/Scenario1/screenshot3.png"));
		WebElement targetElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("datadisplaytable")));

        // Create an instance of the Actions class
        Actions actions = new Actions(driver);

        // Ensure the target element is in view and then right-click on it
        actions.moveToElement(targetElement).contextClick().perform();

        // Create an instance of the Robot class
        Robot robot = new Robot();

        // Use Command + P to open the Print dialog on Mac
        robot.keyPress(KeyEvent.VK_META); // Command key down
        robot.keyPress(KeyEvent.VK_P); // P key down
        robot.keyRelease(KeyEvent.VK_P); // P key up
        robot.keyRelease(KeyEvent.VK_META); // Command key up

        // Wait for the Print dialog to open
        Thread.sleep(2000);

        // Press the 'Enter' key to select the default printer or open Save as PDF dialog
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);

        // Adjust the wait time as needed for the dialog to fully open
        Thread.sleep(2000);

        // Define the desired file name and location
        String fileName = "output.pdf";

        // Type the file name. Adjust for special characters as needed.
        for (char c : fileName.toCharArray()) {
            robot.keyPress(KeyEvent.getExtendedKeyCodeForChar(c));
            robot.keyRelease(KeyEvent.getExtendedKeyCodeForChar(c));
            // Add a small delay between key presses for reliability
            Thread.sleep(50);
        }

        // Press the 'Enter' key to save the PDF
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        
        
		
//		
//		 // Find the target element to right-click
//		WebElement targetElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("datadisplaytable")));
//
//		// Create an instance of the Actions class
//		Actions actions = new Actions(driver);
//
//		// Right-click on the target element
//		actions.contextClick(targetElement).perform();
//
//		// Press the 'P' key to open the Print dialog
//		Robot robot = new Robot();
//		robot.keyPress(KeyEvent.VK_P);
//		robot.keyRelease(KeyEvent.VK_P);
//
//		// Wait for the Print dialog to open (adjust the wait time as needed)
//		Thread.sleep(2000);
//
//		// Press the 'Enter' key to open the Save as PDF dialog
//		robot.keyPress(KeyEvent.VK_ENTER);
//		robot.keyRelease(KeyEvent.VK_ENTER);
//
//		// Wait for the Save as PDF dialog to open (adjust the wait time as needed)
//		Thread.sleep(2000);
//
//		// Type the desired file name and location
//		String fileName = "output.pdf";
//
//		// Type the file name directly
//		for (char c : fileName.toCharArray()) {
//		    robot.keyPress(KeyEvent.getExtendedKeyCodeForChar(c));
//		    robot.keyRelease(KeyEvent.getExtendedKeyCodeForChar(c));
//		    // Add a small delay between key presses for reliability
//		    Thread.sleep(50);
//		}
//
//		// Press the 'Enter' key to save the PDF
//		robot.keyPress(KeyEvent.VK_ENTER);
//		robot.keyRelease(KeyEvent.VK_ENTER);

    }
    
    
}