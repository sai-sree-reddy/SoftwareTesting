package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
//import static org.example.Main.takeScreenshot;
import static org.openqa.selenium.support.ui.ExpectedConditions.numberOfWindowsToBe;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.InputStream;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;



import java.time.Duration;


public class 	S2 {
    WebDriver driver;
    WebDriverWait wait;

    @Parameters("browserName")
    @BeforeTest
    public void InitialiseBrowser(String browserName) {
        switch (browserName.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions options=new ChromeOptions();
                options.addArguments("--disable-extensions");
                HashMap<String, Object> chromePrefs = new HashMap<>();
                chromePrefs.put("plugins.always_open_pdf_externally", true);
                options.setExperimentalOption("prefs", chromePrefs);
                driver = new ChromeDriver(options);
    
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                driver = new FirefoxDriver();
                break;
            default:
                System.out.println("Browser name is invalid");
                break;
        }
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @Parameters("sleepTime")
    @AfterTest
    public void TearDown(Long sleepTime) throws InterruptedException {
        Thread.sleep(sleepTime);
        driver.quit();
    }
    
    
  @Parameters("url")
@Test(priority = 1)
public void LaunchApp(String url) {
    driver.get("https://canvas.northeastern.edu/");
}

@Parameters({"username", "password","loginname" })
@Test(priority = 2)
 public void EnterLoginDetails(String userName, String password, String loginname) throws InterruptedException, IOException {
	  
 

	        
	    	driver.findElement(By.cssSelector(".wp-block-button__link.wp-element-button")).click();
	    	WebElement usernameInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0116")));
	        usernameInput.sendKeys(userName);
	        driver.findElement(By.id("idSIButton9")).click();

	        // Wait for the password field to be clickable and enter the password.
	        WebElement passwordInput = wait.until(ExpectedConditions.elementToBeClickable(By.id("i0118")));
	        passwordInput.sendKeys(password);
	        driver.findElement(By.id("idSIButton9")).click();
	        WebElement otherOptionsLink = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.button--link[href*='/frame/v4/auth/all_methods?sid=frameless-']")));
	        otherOptionsLink.click();

	        WebElement spanElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='method-description-displayed' and contains(text(), 'Send to \"iOS\"')]")));
	        spanElement.click();

	        WebElement trustBrowserButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("trust-browser-button")));
	        trustBrowserButton.click();
	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25)); // Use Duration.ofSeconds for the timeout
	        WebElement No = wait.until(ExpectedConditions.elementToBeClickable(By.id("idBtn_Back")));
	        No.click();
	        WebElement calendarLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("global_nav_calendar_link")));

	     // Click the link
	     calendarLink.click();
	     WebElement createNewEventLink = new WebDriverWait(driver, Duration.ofSeconds(10))
	    	        .until(ExpectedConditions.elementToBeClickable(By.id("create_new_event_link")));
	     String excelFilePath = "/Users/saisreepothireddygari/Documents/SelenimumPractice/data.xlsx";
			FileInputStream inputStream = new FileInputStream(excelFilePath);
			Workbook workbook = new XSSFWorkbook(inputStream);
			Sheet sheet = workbook.getSheet("Sheet1");

	     WebElement calendar = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='global_nav_calendar_link']")));
			calendar.click();
			Thread.sleep(500);
			//takeScreenshot(driver, "createElementBefore", "s2");
			for (int i = 1; i <= 2; i++) {
				Row r = sheet.getRow(i);
				String title = r.getCell(3).getStringCellValue();
				String date = r.getCell(4).getStringCellValue();
				String time = r.getCell(5).getNumericCellValue() + "";
				String Details = r.getCell(7).getStringCellValue();
			// Add action
				WebElement add = wait
						.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='create_new_event_link']")));
         		add.click();

 				// To-do action
				WebElement event1 = wait
					.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"edit_event_tabs\"]/ul/li[2]")));
				event1.click();

				Thread.sleep(2000);
				WebElement titleW = driver.findElement(By.id("planner_note_title"));
				WebElement dateW = driver.findElement(By.id("planner_note_date"));
				WebElement timeW = driver.findElement(By.id("planner_note_time"));
			WebElement detailW = driver.findElement(By.id("details_textarea"));
				titleW.sendKeys(title);
				dateW.clear();
				dateW.sendKeys(date);
				timeW.sendKeys(time);
				detailW.sendKeys(Details);

				Thread.sleep(500);
    //takeScreenshot(driver, "createElementbeforeClick" + i, "s2");
				WebElement submit = driver
						.findElement(By.xpath("//*[@id=\"edit_planner_note_form_holder\"]/form/div[2]/button"));
				submit.click();
	 
	    	
	    	
	    }
	    
}
}